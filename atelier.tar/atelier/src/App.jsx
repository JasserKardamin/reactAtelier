import { Events } from "./componets/Events";
import "./App.css";

function App() {
  return (
    <div className="w-100">
      <Events />
    </div>
  );
}

export default App;
